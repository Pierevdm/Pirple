# My Funtion Homework Assignment

SongName = "Zombie"
Artists = "Bad Wolves"
Genre = "Hard Rock"

def Songname():
    print (SongName)
Songname()

def Artist():
    print (Artists)
Artist()

def genre():
    print (Genre)
genre()



    