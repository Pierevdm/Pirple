#Title - Details regarding project
print("This Is a  Project about my favorite song and all the details regarding it.")

# Favorite Current Song
SongName = "Zombie"
Artist = "Bad Wolves"
Genre = "Hard Rock"
Album = "Disobey"
Label = " Eleven Seven"
SongLength = 4.15*60
ReleaseDate = "18 January 2018"
ChartPosUS = 8
Writer="Dolores O'Riordan"
Website="www.badwolvesnation.com"
NumberInBand=5
Members="Tommy Vext, John Boecklin, Doc Coyle, Chris Cain, Kyle Konkiel"
Original="The Cranberries"
AlbumQty=2

#Song Title
print(SongName)
#Artist
print(Artist)
# Genre Of Music
print(Genre)
# Name of Album
print(Album)
#Release Date
print(ReleaseDate)
#Label Releasing Album
print(Label)
#Chart Position, Billboard End of the Year USA
print(ChartPosUS)
# Length Of Song in Seconds
print(SongLength)
#Songwriter
print(Writer)
#Website
print(Website)
# Number Of Members in Band
print(NumberInBand)
#Band Members
print(Members)
#Origianl Artists
print(Original)
#Number of Albums by
print(AlbumQty)
